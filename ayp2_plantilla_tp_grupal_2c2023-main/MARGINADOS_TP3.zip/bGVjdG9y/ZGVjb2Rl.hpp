#ifndef ZGVJB2RL_HPP
#define ZGVJB2RL_HPP

#include <string>
#include <algorithm>

class ZGVjb2Rl {
private:
    static const std::string YmFzZTY0X2NoYXJz;
public:
    static inline bool aXNfYmFzZTY0(unsigned char Yw);

    static std::string YmFzZV82NF9kZWNvZGU(std::string const& ZW5jb2RlZA);
};

#endif