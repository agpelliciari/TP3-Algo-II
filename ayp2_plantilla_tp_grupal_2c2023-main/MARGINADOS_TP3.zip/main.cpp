#include "include/Juego.hpp"


int main() {

	Juego juego;

	juego.inicializar_juego();

    return 0;
}